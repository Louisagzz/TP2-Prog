#!/bin/bash

set -e -u -o pipefail

git config --global pull.rebase false
git config --global core.editor 'false'

pipx install uv
uv venv --python 3.13
uv pip install -r requirements.txt
